package edu.cvtc.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 * Servlet implementation class ContactServlet
 */
@WebServlet("/ContactServlet")
public class ContactServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out = response.getWriter();
		
		out.append("<!doctype html>\n<html>\n<head>\n\t<title>\n\t\tMy Website\n\t</title>\n</head>\n<body>");
		out.append("\n\t<h1>\n\t\tContact Information\n\t</h1>");
		out.append("\n\t<nav>\n\t\t<ul>\n\t\t\t<li><a href='http://localhost:8080/MyWebsite/HomeServlet'>Home</a></li>");
		out.append("\n\t\t\t<li><a href='http://localhost:8080/MyWebsite/AboutServlet'>About</a></li>");
		out.append("\n\t\t\t<li><a href='http://localhost:8080/MyWebsite/ContactServlet'>Contact</a></li>\n\t\t</ul>\n\t</nav>");
		
		out.append("\n\t<p>\n\t\tIf you need to get ahold of me you can find all of my information listed below.\n\t</p>");
		out.append("\n\t<p>\n\t\tEmail Address - <a href='mailto:rruf7@student.cvtc.edu'>rruf7@student.cvtc.edu</a>\n\t</p>");
		out.append("\n\t<p>\n\t\tAddress - Ryan Ruf<br>\n\t\t10601 147th Ave<br>\n\t\tBloomer WI, 54724\n\t</p>");
		out.append("\n\t<p>\n\t\tPhone Number - 715-933-1656\n\t</p>");
		
		out.append("\n\t<p>\n\t\tIf you would like to leave your information just fill out the form below and I'll get back to you as soon as possible!\n\t</p>");
		out.append("\n\t<form action='index.jsp method='POST>\n\t\t<div>\n\t\t\t<label for='firstName'>First Name:</label>"
				+ "\n\t\t\t<input type='text' id='firstName' name='firstName' />\n\t\t</div>");
		out.append("\n\t\t<div>\n\t\t\t<label for='lastName'>Last Name:</label>"
				+ "\n\t\t\t<input type='text' id='lastName' name='lastName' />\n\t\t</div>");
		out.append("\n\t\t<div>\n\t\t\t<label for='emailAddress'>Email Address:</label>"
				+ "\n\t\t\t<input type='text' id='emailAddress' name='emailAddress' />\n\t\t</div>");
		out.append("<input type='submit' name='send' value='send' id='send' />\n\t</form>");
		
		out.append("\n\t<p>\n\t\t&copy; Copyright 2016 Ryan Ruf\n\t</p>");
		out.append("\n</body>\n</html>");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
	
}











