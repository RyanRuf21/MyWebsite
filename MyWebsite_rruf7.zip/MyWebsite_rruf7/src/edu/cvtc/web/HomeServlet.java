package edu.cvtc.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class HomeServlet
 */
@WebServlet("/HomeServlet")
public class HomeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out = response.getWriter();
		
		out.append("<!doctype html>\n<html>\n<head>\n\t<title>\n\t\tMy Website\n\t</title>\n</head>\n<body>");
		out.append("\n\t<h1>\n\t\tHome\n\t</h1>");
		out.append("\n\t<nav>\n\t\t<ul>\n\t\t\t<li><a href='http://localhost:8080/MyWebsite/HomeServlet'>Home</a></li>");
		out.append("\n\t\t\t<li><a href='http://localhost:8080/MyWebsite/AboutServlet'>About</a></li>");
		out.append("\n\t\t\t<li><a href='http://localhost:8080/MyWebsite/ContactServlet'>Contact</a></li>\n\t\t</ul>\n\t</nav>");
		out.append("\n\t<p>\n\t\tThis website will contain information about myself. You can find some personal information on the about page."
				+ "\n\t\tIf you have any questions or concerns you can find my contact information on the contact page as well as a form to fill out regarding your information.\n\t</p>");
		out.append("\n\t<p>\n\t\t&copy; Copyright 2016 Ryan Ruf\n\t</p>");
		out.append("\n</body>\n</html>");
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
