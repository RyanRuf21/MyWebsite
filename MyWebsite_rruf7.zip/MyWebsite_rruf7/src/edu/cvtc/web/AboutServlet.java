package edu.cvtc.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class AboutServlet
 */
@WebServlet("/AboutServlet")
public class AboutServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out = response.getWriter();
		
		out.append("<!doctype html>\n<html>\n<head>\n\t<title>\n\t\tMy Website\n\t</title>\n</head>\n<body>");
		out.append("\n\t<h1>\n\t\tAbout Me\n\t</h1>");
		out.append("\n\t<nav>\n\t\t<ul>\n\t\t\t<li><a href='http://localhost:8080/MyWebsite/HomeServlet'>Home</a></li>");
		out.append("\n\t\t\t<li><a href='http://localhost:8080/MyWebsite/AboutServlet'>About</a></li>");
		out.append("\n\t\t\t<li><a href='http://localhost:8080/MyWebsite/ContactServlet'>Contact</a></li>\n\t\t</ul>\n\t</nav>");
		out.append("\n\t<section>\n\t\t<p>\n\t\t\tMy name is Ryan Ruf and I grew up in the town of Bloomer."
				+ "\n\t\t\t Since I was in 8th grade I have been working on the neighbors farm up until a year ago when I started working at Hardee's."
				+ "\n\t\t\t I spent most of that time going to UWEC to become a teacher until I recently switched to the IT-SD and IT-MD programs here at CVTC. \n\t\t</p>\n\t</section>");
		out.append("\n\t<section>\n\t\t<h2>Some of my hobbies include:</h2>"
				+ "\n\t\t<ul>\n\t\t\t<li>Playing volleyball and other sports</li>"
				+ "\n\t\t\t<li>Going fishing</li>"
				+ "\n\t\t\t<li>Watching sports or movies</li>"
				+ "\n\t\t\t<li>Playing video games or board games</li>"
				+ "\n\t\t\t<li>Hanging out with friends</li>\n\t\t</ul>\n\t</section>");
		out.append("\n\t<section>\n\t\t<p>\n\t\t\tI will be graduating school this fall, December 2016, and after I graduate my goal is to get a full time job somewhere."
				+ "\n\t\t\tI currently just got hired as an intern in the POS department at Menards, Inc, so there's a possiblity I will get hired on there when I graduate."
				+ "\n\t\t\tThere is also the possiblity that I might try to get a job somewhere else."
				+ "\n\t\t</p>\n\t</section>");
		out.append("\n\t<p>\n\t\t&copy; Copyright 2016 Ryan Ruf\n\t</p>");
		out.append("\n</body>\n</html>");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
